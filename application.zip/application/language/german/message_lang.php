<?php
$lang['welcome_message'] = "Willkommen im Krankenhaus-Management-System";
