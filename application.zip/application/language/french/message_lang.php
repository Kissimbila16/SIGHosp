<?php
$lang['welcome_message'] = "Bienvenue au système de gestion de l'hôpital";
