<?php
$lang['welcome_message'] = "Welcome to Hospital Management System";
