<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>#</th>
				<th>Medicamento</th>
				<th>Dose</th>
				<th>Tempo Medicação</th>
			</tr>
		</thead>
		<tbody>
			<?php
			$count = 1;
			$prescription_details	=	$this->security->xss_clean($this->db->get_where('prescription_details', array('prescription_id' => $param2))->result_array());
			foreach ($prescription_details as $prescription_detail) :
			?>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>
						<?php 
							if ($this->db->get_where('medicine', array('medicine_id' => $prescription_detail['medicine_id']))->num_rows() > 0)
								echo $this->security->xss_clean($this->db->get_where('medicine', array('medicine_id' => $prescription_detail['medicine_id']))->row()->name); 
							else
								echo 'Medicamento não foi encontrado.';
						?>
					</td>
					<td><?php echo $prescription_detail['dose']; ?></td>
					<td><?php echo $prescription_detail['medication_time']; ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php
	$symptoms 	= $this->security->xss_clean($this->db->get_where('prescription', array('prescription_id' => $param2))->row()->symptoms);
	$extra_note = $this->security->xss_clean($this->db->get_where('prescription', array('prescription_id' => $param2))->row()->extra_note);
	if ($symptoms) :
	?>
		<div class="note note-info">
			<h4>Sintomas</h4>
			<p><?php echo $symptoms; ?></p>
		</div>
	<?php
	endif;
	if ($extra_note) :
	?>
		<div class="note note-success">
			<h4>Nota Extra</h4>
			<p><?php echo $extra_note; ?></p>
		</div>
	<?php endif; ?>

	<button type="button" class="btn btn-warning" data-dismiss="modal" aria-label="Close">Fechar</button>
</div>