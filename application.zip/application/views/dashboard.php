<!-- begin #content -->
<div id="content" class="content  bg-white">
	<!-- begin breadcrumb -->
	<ol class="breadcrumb pull-right">
		<li class="breadcrumb-item active">Dashboard</li>
	</ol>
	<!-- end breadcrumb -->
	<!-- begin page-header -->
	<h1 class="page-header">Bem vindo </small></h1>
	<!-- end page-header -->

	<!-- begin row -->
	<div class="row">
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-user-md text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Doctores</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('doctor')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>staff_categories">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-user text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Funcionárias</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('staff')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>staff_categories">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-users text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Pacientes</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('patient')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>patients">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-building text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Acommodações</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('accommodation')->num_rows()) + $this->security->xss_clean($this->db->get('bed')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>accommodation_categories">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->

		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-heartbeat text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Laboratórios</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('laboratory')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>laboratories">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-file text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Relatórios</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('report')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>reports">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-life-ring text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Doadores de Sangue</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('blood_donor')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>blood_donors">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-hospital text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Pedidos de sangue</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('blood_request')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>blood_requests">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-bed text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Ocupações</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('occupancy')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>occupancies">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-home text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Descargas</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('discharge')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>discharges">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-address-book text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Apontamentos</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('appointment')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>appointments">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-credit-card text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Faturas</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('invoice')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>invoices">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-ambulance text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Transportes</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('transport')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>transport_categories">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-id-badge text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Certificados</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('certificate')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>certificates">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-podcast text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Notícias</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('notice')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>notices">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-comments text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Feedback & Qualificações</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('feedback')->num_rows()) + $this->security->xss_clean($this->db->get('rating')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url(); ?>feedback_and_ratings">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
		<!-- begin col-3 -->
		<div class="col-lg-2 col-md-6">
			<div class="widget widget-stats" style="background:#00ccff;color:black;">
				<div class="stats-icon"><i class="fa fa-life-ring text-white"></i></div>
				<div class="stats-info">
					<h4 class="text-white"><b>Tickets</b></h4>
					<p class="text-white"><?php echo html_escape($this->security->xss_clean($this->db->get('ticket')->num_rows())); ?></p>
				</div>
				<div class="stats-link  text-white" style="color:#00ccff;">
					<a href="<?php echo base_url('tickets'); ?>">Ver Detalhes <i class="fa fa-arrow-alt-circle-right"></i></a>
				</div>
			</div>
		</div>
		<!-- end col-3 -->
	</div>
	<!-- end row -->
</div>
<!-- end #content -->