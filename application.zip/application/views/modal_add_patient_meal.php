<?php echo form_open('patient_meals/create', array('id' => 'create_patient_meal', 'class' => 'form-horizontal', 'method' => 'post', 'data-parsley-validate' => 'true')); ?>
<div class="form-group">
	<label class="col-md-12 col-form-label">Acommodação *</label>
	<div class="col-md-12">
		<select style="width: 100%" class="form-control default-select2" name="occupancy_id" data-parsley-required="true">
			<option value="">Selecione a Acommodação</option>
			<?php
			$occupancies = $this->security->xss_clean($this->db->get_where('occupancy', array('status' => 1))->result_array());
			foreach ($occupancies as $occupancy) :
				if ($this->security->xss_clean($this->db->get_where('accommodation_category', array('accommodation_category_id' => $occupancy['accommodation_category_id']))->row()->accommodation_type) == 1) :
			?>
					<optgroup label="<?php echo $this->security->xss_clean($this->db->get_where('accommodation_category', array('accommodation_category_id' => $occupancy['accommodation_category_id']))->row()->name); ?>">
						<?php
						$beds = $this->security->xss_clean($this->db->get_where('bed', array('status' => 1, 'accommodation_category_id' => $occupancy['accommodation_category_id']))->result_array());
						foreach ($beds as $bed) :
						?>
							<option value="<?php echo $occupancy['occupancy_id']; ?>">Cama <?php echo $bed['bed_number']; ?> of Room <?php echo $this->security->xss_clean($this->db->get_where('accommodation', array('accommodation_id' => $bed['accommodation_id']))->row()->room_number); ?></option>
						<?php endforeach; ?>
					</optgroup>
				<?php elseif ($this->security->xss_clean($this->db->get_where('accommodation_category', array('accommodation_category_id' => $occupancy['accommodation_category_id']))->row()->accommodation_type) == 0) : ?>
					<optgroup label="<?php echo $this->security->xss_clean($this->db->get_where('accommodation_category', array('accommodation_category_id' => $occupancy['accommodation_category_id']))->row()->name); ?>">
						<?php
						$accommodations = $this->security->xss_clean($this->db->get_where('accommodation', array('status' => 1, 'accommodation_category_id' => $occupancy['accommodation_category_id']))->result_array());
						foreach ($accommodations as $accommodation) :
						?>
							<option value="<?php echo $occupancy['occupancy_id']; ?>">Sala <?php echo $accommodation['room_number']; ?></option>
						<?php endforeach; ?>
					</optgroup>
			<?php
				endif;
			endforeach;
			?>
		</select>
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Doutor *</label>
	<div class="col-md-12">
		<select style="width: 100%" class="form-control default-select2" name="doctor_id" data-parsley-required="true">
			<option value="">Selecione o doutor</option>
			<?php
			$doctors = $this->security->xss_clean($this->db->get('doctor')->result_array());
			foreach ($doctors as $doctor) :
			?>
				<option value="<?php echo $doctor['doctor_id']; ?>"><?php echo $doctor['name']; ?></option>
			<?php endforeach; ?>
		</select>
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Almoço</label>
	<div class="col-md-12">
		<input name="breakfast" type="text" class="form-control" placeholder="Tipo de almoço para o paciente" />
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">pausa para leite</label>
	<div class="col-md-12">
		<input name="milk_break" type="text" class="form-control" placeholder="Tipo de pausa para leite para o paciente" />
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Lanche</label>
	<div class="col-md-12">
		<input name="lunch" type="text" class="form-control" placeholder="Tipo Lanche para o paciente" />
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Tea Break</label>
	<div class="col-md-12">
		<input name="tea_break" type="text" class="form-control" placeholder="Tipo de pausa para o chá do o paciente" />
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Jantar</label>
	<div class="col-md-12">
		<input name="dinner" type="text" class="form-control" placeholder="Tipo jantar para o paciente" />
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Nota Extra</label>
	<div class="col-md-12">
		<textarea name="extra_note" class="form-control" placeholder="Tipo de instrucões" rows="5"></textarea>
	</div>
</div>

<div class="form-group">
	<label class="col-md-12 col-form-label"></label>
	<div class="col-md-12">
		<button type="button" class="btn btn-warning" data-dismiss="modal" aria-label="Close">Cancelar</button>
		<button type="submit" class="btn btn-yellow pull-right">Submeter</button>
	</div>
</div>
<?php echo form_close(); ?>

<script>
	"use strict";
	
	$('#create_patient_meal').parsley();
	FormPlugins.init();
</script>