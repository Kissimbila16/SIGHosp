<?php echo form_open('pharmacy_inventory/create', array('id' => 'create_pharmacy_inventory', 'class' => 'form-horizontal', 'method' => 'post', 'data-parsley-validate' => 'true')); ?>
<div class="form-group">
	<label class="col-md-12 col-form-label">Nome *</label>
	<div class="col-md-12">
		<input name="name" type="text" data-parsley-required="true" class="form-control" placeholder="Tipo inventorio" />
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Codigo do Produto  *</label>
	<div class="col-md-12">
		<input name="code" type="text" data-parsley-required="true" class="form-control" placeholder="Tipo de codigo do inventorio" />
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Unit *</label>
	<div class="col-md-12">
		<select style="width: 100%" class="form-control default-select2" data-parsley-required="true" name="unit_id">
			<option value="">Select unit</option>
			<?php
			$units = $this->security->xss_clean($this->db->get_where('unit', array('unit_for' => 1))->result_array());
			foreach ($units as $unit) :
			?>
				<option value="<?php echo html_escape($unit['unit_id']); ?>"><?php echo $unit['name']; ?></option>
			<?php endforeach; ?>
		</select>
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Unit Price (<?php echo $this->security->xss_clean($this->db->get_where('setting', array('item' => 'currency'))->row()->content); ?>) *</label>
	<div class="col-md-12">
		<input name="price" data-parsley-type="number" data-parsley-min="0" data-parsley-required="true" class="form-control" placeholder="Tipo de  preço unit do inventorio" />
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Quantidade  *</label>
	<div class="col-md-12">
		<input name="quantity" data-parsley-type="number" data-parsley-min="0" data-parsley-required="true" class="form-control" placeholder=" quantidade do preço unitário" />
	</div>
</div>

<div class="form-group">
	<label class="col-md-12 col-form-label"></label>
	<div class="col-md-12">
		<button type="button" class="btn btn-warning" data-dismiss="modal" aria-label="Close">Cancelar</button>
		<button type="submit" class="btn btn-yellow pull-right">Submeter</button>
	</div>
</div>
<?php echo form_close(); ?>

<script>
	"use strict";
	
	$('#create_pharmacy_inventory').parsley();
	FormPlugins.init();
</script>