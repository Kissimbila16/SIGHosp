<?php echo form_open('laboratories/create', array('id' => 'create_laboratory', 'class' => 'form-horizontal', 'method' => 'post', 'data-parsley-validate' => 'true')); ?>
<div class="form-group">
	<label class="col-md-12 col-form-label">Nome *</label>
	<div class="col-md-12">
		<input name="name" type="text" data-parsley-required="true" class="form-control" placeholder="digite" />
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Numero da Sala *</label>
	<div class="col-md-12">
		<input name="room_number" type="text" data-parsley-required="true" class="form-control" placeholder="digite" />
	</div>
</div>

<div class="form-group">
	<label class="col-md-12 col-form-label"></label>
	<div class="col-md-12">
		<button type="button" class="btn btn-warning" data-dismiss="modal" aria-label="Close">Cancelar</button>
		<button type="submit" class="btn btn-yellow pull-right">Submeter</button>
	</div>
</div>
<?php echo form_close(); ?>

<script>
	"use strict";
	
	$('#create_laboratory').parsley();
	FormPlugins.init();
</script>