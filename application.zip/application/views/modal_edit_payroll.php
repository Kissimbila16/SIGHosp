<?php echo form_open('payroll/update/' . $param2, array('id' => 'update_payroll', 'class' => 'form-horizontal', 'method' => 'post', 'data-parsley-validate' => 'true')); ?>
<?php
$user_id	=	$this->security->xss_clean($this->db->get_where('payroll', array('payroll_id' => $param2))->row()->user_id);
$year 		= 	$this->security->xss_clean($this->db->get_where('payroll', array('payroll_id' => $param2))->row()->year);
$month 		=	$this->security->xss_clean($this->db->get_where('payroll', array('payroll_id' => $param2))->row()->month);
$amount 	=	$this->security->xss_clean($this->db->get_where('payroll', array('payroll_id' => $param2))->row()->amount);
?>
<div class="form-group">
	<label class="col-md-12 col-form-label">funcionarios *</label>
	<div class="col-md-12">
		<select disabled="true" style="width: 100%" class="form-control default-select2" data-parsley-required="true" name="user_id">
			<option value="">Selecionar funcionario</option>
			<?php
			$staff_categories = $this->security->xss_clean($this->db->get_where('staff_category', array('pay_scale >' => 0))->result_array());
			foreach ($staff_categories as $staff_category) :
			?>
				<optgroup label="<?php echo $staff_category['name']; ?>">
					<?php
					if ($staff_category['is_doctor']) :
						$doctors =  $this->security->xss_clean($this->db->get_where('doctor', array('staff_category_id' => $staff_category['staff_category_id']))->result_array());
						foreach ($doctors as $doctor) :
							$doctor_user_id = $this->security->xss_clean($this->db->get_where('user', array('staff_category_id' => $staff_category['staff_category_id'], 'staff_id' => $doctor['doctor_id']))->row()->user_id);
					?>
							<option <?php if ($user_id == $doctor_user_id) echo 'selecionado'; ?> value="<?php echo html_escape($doctor_user_id); ?>"><?php echo $doctor['name']; ?></option>
						<?php
						endforeach;
					else :
						$staff =  $this->security->xss_clean($this->db->get_where('staff', array('staff_category_id' => $staff_category['staff_category_id']))->result_array());
						foreach ($staff as $row) :
							$staff_user_id = $this->security->xss_clean($this->db->get_where('user', array('staff_category_id' => $staff_category['staff_category_id'], 'staff_id' => $row['staff_id']))->row()->user_id);
						?>
							<option <?php if ($user_id == $staff_user_id) echo 'selecionado'; ?> value="<?php echo html_escape($staff_user_id); ?>"><?php echo $row['name']; ?></option>
					<?php
						endforeach;
					endif;
					?>
				</optgroup>
			<?php endforeach; ?>
		</select>
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Anual *</label>
	<div class="col-md-12">
		<select style="width: 100%" class="form-control default-select2" data-parsley-required="true" name="year">
			<option value="">Select Year</option>
			<option <?php if ($year == date('Y') - 4) echo 'selecionado'; ?> value="<?php echo date('Y') - 4; ?>"><?php echo date('Y') - 4; ?></option>
			<option <?php if ($year == date('Y') - 3) echo 'selecionado'; ?> value="<?php echo date('Y') - 3; ?>"><?php echo date('Y') - 3; ?></option>
			<option <?php if ($year == date('Y') - 2) echo 'selecionado'; ?> value="<?php echo date('Y') - 2; ?>"><?php echo date('Y') - 2; ?></option>
			<option <?php if ($year == date('Y') - 1) echo 'selecionado'; ?> value="<?php echo date('Y') - 1; ?>"><?php echo date('Y') - 1; ?></option>
			<option <?php if ($year == date('Y')) echo 'selecionado'; ?> value="<?php echo date('Y'); ?>"><?php echo date('Y'); ?></option>
			<option <?php if ($year == date('Y') + 1) echo 'selecionado'; ?> value="<?php echo date('Y') + 1; ?>"><?php echo date('Y') + 1; ?></option>
			<option <?php if ($year == date('Y') + 2) echo 'selecionado'; ?> value="<?php echo date('Y') + 2; ?>"><?php echo date('Y') + 2; ?></option>
			<option <?php if ($year == date('Y') + 3) echo 'selecionado'; ?> value="<?php echo date('Y') + 3; ?>"><?php echo date('Y') + 3; ?></option>
			<option <?php if ($year == date('Y') + 4) echo 'selecionado'; ?> value="<?php echo date('Y') + 4; ?>"><?php echo date('Y') + 4; ?></option>
		</select>
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Mensal *</label>
	<div class="col-md-12">
		<select style="width: 100%" class="form-control default-select2" data-parsley-required="true" name="month">
			<option value="">Select Month</option>
			<option <?php if ($month == 'January') echo 'selecionado'; ?> value="January">Janeiro</option>
			<option <?php if ($month == 'February') echo 'selecionado'; ?> value="February">Fevereiro</option>
			<option <?php if ($month == 'March') echo 'selecionado'; ?> value="March">Março</option>
			<option <?php if ($month == 'April') echo 'selecionado'; ?> value="April">Abril</option>
			<option <?php if ($month == 'May') echo 'selecionado'; ?> value="May">Maio</option>
			<option <?php if ($month == 'June') echo 'selecionado'; ?> value="June">Junho</option>
			<option <?php if ($month == 'July') echo 'selecionado'; ?> value="July">Julho</option>
			<option <?php if ($month == 'August') echo 'selecionado'; ?> value="August">Agosto</option>
			<option <?php if ($month == 'September') echo 'selecionado'; ?> value="September">Setembro</option>
			<option <?php if ($month == 'October') echo 'selecionado'; ?> value="October">Outobro</option>
			<option <?php if ($month == 'November') echo 'selecionado'; ?> value="November">Novembro</option>
			<option <?php if ($month == 'December') echo 'selecionado'; ?> value="December">Dezembro</option>
		</select>
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Monte (<?php echo $this->security->xss_clean($this->db->get_where('setting', array('item' => 'currency'))->row()->content); ?>) *</label>
	<div class="col-md-12">
		<input value="<?php echo $amount; ?>" class="form-control" title="Type amount" name="amount" data-parsley-required="true" data-parsley-min="0" data-parsley-type="number">
	</div>
</div>

<div class="form-group">
	<label class="col-md-12 col-form-label"></label>
	<div class="col-md-12">
		<button type="button" class="btn btn-warning" data-dismiss="modal" aria-label="Close">Cancelar</button>
		<button type="submit" class="btn btn-yellow pull-right">Actualizar</button>
	</div>
</div>
<?php echo form_close(); ?>

<script>
	"use strict";
	
	$('#update_payroll').parsley();
	FormPlugins.init();
</script>