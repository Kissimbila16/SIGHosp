<?php echo form_open('blood_requests/update/' . $param2, array('id' => 'update_blood_request_details', 'class' => 'form-horizontal', 'method' => 'post', 'data-parsley-validate' => 'true')); ?>
<?php
$blood_request_details = $this->security->xss_clean($this->db->get_where('blood_request', array('blood_request_id' => $param2))->result_array());
foreach ($blood_request_details as $row) :
?>
	<div class="form-group">
		<label class="col-md-12 col-form-label">Blood Group *</label>
		<div class="col-md-12">
			<select style="width: 100%" class="form-control default-select2" data-parsley-required="true" name="blood_inventory_id">
				<option value="">Select blood group</option>
				<?php
				$blood_groups = $this->security->xss_clean($this->db->get('blood_inventory')->result_array());
				foreach ($blood_groups as $blood_group) :
				?>
					<option <?php if ($blood_group['blood_inventory_id'] == $row['blood_inventory_id']) echo 'selected'; ?> value="<?php echo html_escape($blood_group['blood_inventory_id']); ?>"><?php echo $blood_group['blood_group_name']; ?></option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-12 col-form-label">Sangue doador *</label>
		<div class="col-md-12">
			<select style="width: 100%" class="form-control default-select2" data-parsley-required="true" name="blood_donor_id">
				<option value="">Selecione o Sangue do doador</option>
				<?php
				$blood_donors = $this->security->xss_clean($this->db->get_where('blood_donor', array('status' => 0))->result_array());
				foreach ($blood_donors as $blood_donor) :
				?>
					<option <?php if ($blood_donor['blood_donor_id'] == $row['blood_donor_id']) echo 'selected'; ?> value="<?php echo html_escape($blood_donor['blood_donor_id']); ?>"><?php echo $blood_donor['name']; ?></option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-12 col-form-label">Proposito *</label>
		<div class="col-md-12">
			<textarea name="purpose" data-parsley-required="true" class="form-control" placeholder="" rows="5"><?php echo $row['purpose']; ?></textarea>
		</div>
	</div>
	<div class="form-group">
		<label class="col-md-12 col-form-label">Doutor *</label>
		<div class="col-md-12">
			<select style="width: 100%" class="form-control default-select2" data-parsley-required="true" name="doctor_id">
				<option value="">Selecione a referencia do doutor</option>
				<?php
				$doctor_categories = $this->security->xss_clean($this->db->get_where('staff_category', array('is_doctor' => 1))->result_array());
				foreach ($doctor_categories as $doctor_category) :
				?>
					<optgroup label="<?php echo $doctor_category['name']; ?>">
						<?php
						$doctors = $this->security->xss_clean($this->db->get_where('doctor', array('staff_category_id' => $doctor_category['staff_category_id']))->result_array());
						foreach ($doctors as $doctor) :
						?>
							<option <?php if ($doctor['doctor_id'] == $row['doctor_id']) echo 'selected'; ?> value="<?php echo $doctor['doctor_id']; ?>"><?php echo $doctor['name']; ?></option>
						<?php endforeach; ?>
					</optgroup>
				<?php endforeach; ?>
			</select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-md-12 col-form-label"></label>
		<div class="col-md-12">
			<button type="button" class="btn btn-warning" data-dismiss="modal" aria-label="Close">Cancelar</button>
			<button type="submit" class="btn btn-yellow pull-right">Actualizar</button>
		</div>
	</div>
<?php endforeach; ?>
<?php echo form_close(); ?>

<script>
	"use strict";
	
	$('#update_blood_request_details').parsley();
	FormPlugins.init();
</script>