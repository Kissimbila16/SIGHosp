<!-- begin #content -->
<div id="content" class="content">
	<!-- begin breadcrumb -->
	<ol class="breadcrumb pull-right">
		<li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Dashboard</a></li>
		<li class="breadcrumb-item active"><?php echo $this->security->xss_clean($page_title); ?></li>
	</ol>
	<!-- end breadcrumb -->
	<?php if ($this->session->userdata('user_type') == 'staff'): ?>
	<!-- begin page-header -->
	<h1 class="page-header">
		<a onclick="showAjaxModal('<?php echo base_url(); ?>modal/popup/modal_add_occupancy');" href="javascript:;" class="btn btn-inverse m-r-5">
			<i class="fa fa-plus"></i> Add Ocupação
		</a>
	</h1>
	<!-- end page-header -->
	<?php else: ?>
	<!-- begin page-header -->
	<h1 class="page-header">
		Detalhes da  Ocupação 
	</h1>
	<!-- end page-header -->
	<?php endif; ?>

	<!-- begin row -->
	<div class="row">
		<!-- begin col-12 -->
		<div class="col-md-12">
			<!-- begin panel -->
			<div class="panel panel-inverse">
				<div class="panel-body">
					<table id="data-table-buttons" class="table table-striped table-bordered">
						<thead>
							<tr>
								<th>#</th>
								<th>PID</th>
								<th>Nome</th>
								<th>Categoria Acommodação </th>
								<th>Acommodação</th>
								<th>Estado</th>
								<th>Criador em</th>
								<th>Criado por</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<?php
							$count = 1;
							$this->db->order_by('timestamp', 'desc');
							if ($this->session->userdata('user_type') == 'staff') {
								$occupancies = $this->security->xss_clean($this->db->get('occupancy')->result_array());
							} else {
								$occupancies = $this->security->xss_clean($this->db->get_where('occupancy', array('patient_id' => $this->session->userdata('user_id')))->result_array());
							}			
							foreach ($occupancies as $row) :
							?>
								<tr>
									<td><?php echo $count++; ?></td>
									<td>
										<?php 
											if ($this->db->get_where('patient', array('patient_id' => $row['patient_id']))->num_rows() > 0)
												echo $this->security->xss_clean($this->db->get_where('patient', array('patient_id' => $row['patient_id']))->row()->pid); 
											else 
												echo 'Paciente ID não foi encontrado.';
										?>
									</td>
									<td>
										<?php 
											if ($this->db->get_where('patient', array('patient_id' => $row['patient_id']))->num_rows() > 0)
												echo $this->security->xss_clean($this->db->get_where('patient', array('patient_id' => $row['patient_id']))->row()->name); 
											else 
												echo 'Paciente não foi encontrado.';
										?>
									</td>
									<?php
									if ($this->db->get_where('accommodation_category', array('accommodation_category_id' => $row['accommodation_category_id']))->num_rows() > 0):
										$accommodation_type	=	$this->security->xss_clean($this->db->get_where('accommodation_category', array('accommodation_category_id' => $row['accommodation_category_id']))->row()->accommodation_type);
										if ($accommodation_type == 1) :
									?>
										<td>
											<?php
											if ($this->db->get_where('bed', array('accommodation_category_id' => $row['accommodation_category_id']))->num_rows() > 0) {
												$root_accommodation_category_id = $this->security->xss_clean($this->db->get_where('bed', array('accommodation_category_id' => $row['accommodation_category_id']))->row()->root_accommodation_category_id);
												if ($this->db->get_where('accommodation_category', array('accommodation_category_id' => $root_accommodation_category_id))->num_rows() > 0)
													echo $this->security->xss_clean($this->db->get_where('accommodation_category', array('accommodation_category_id' => $root_accommodation_category_id))->row()->name);
												else
													echo 'Categoria de Acomodação  não foi encontrado..';

											} else {
												echo 'Cama não foi encontrado..';
											}
											?>
										</td>
										<td>
											<?php
											if ($this->db->get_where('bed', array('bed_id' => $row['accommodation_id']))->num_rows() > 0 && $this->db->get_where('bed', array('bed_id' => $row['accommodation_id']))->row()->accommodation_id) {
												$accommodation_id = $this->security->xss_clean($this->db->get_where('bed', array('bed_id' => $row['accommodation_id']))->row()->accommodation_id);
												if ($this->db->get_where('bed', array('bed_id' => $row['accommodation_id']))->num_rows() > 0)
													echo 'Cama ' . $this->security->xss_clean($this->db->get_where('bed', array('bed_id' => $row['accommodation_id']))->row()->bed_number) . ' da Sala ' . ($this->db->get_where('accommodation', array('accommodation_id' => $accommodation_id))->num_rows() > 0 ? $this->security->xss_clean($this->db->get_where('accommodation', array('accommodation_id' => $accommodation_id))->row()->room_number) : 'não foi encontrado.');
												else
													echo 'Cama não foi encontrado na Sala ' . $this->db->get_where('accommodation', array('accommodation_id' => $accommodation_id))->num_rows() > 0 ? $this->security->xss_clean($this->db->get_where('accommodation', array('accommodation_id' => $accommodation_id))->row()->room_number) : 'não foi encontrado.';
											} else {
												echo 'Acomodação não foi encontrado.';
											}
											?>
										</td>
									<?php else : ?>
										<td>
											<?php 
												if ($this->db->get_where('accommodation_category', array('accommodation_category_id' => $row['accommodation_category_id']))->num_rows() > 0)
													echo $this->security->xss_clean($this->db->get_where('accommodation_category', array('accommodation_category_id' => $row['accommodation_category_id']))->row()->name); 
												else 
													echo 'Categoria de Acomodação  não foi encontrado.';
											?>
										</td>
										<td>
											<?php 
												if ($this->db->get_where('accommodation', array('accommodation_id' => $row['accommodation_id']))->num_rows() > 0)
													echo 'Sala ' . $this->security->xss_clean($this->db->get_where('accommodation', array('accommodation_id' => $row['accommodation_id']))->row()->room_number); 
												else
													echo 'Sala não foi encontrado.';
											?>
										</td>
									<?php
										endif;
									else : 'Categoria de Acomodação não foi encontrado..';
									endif; 
									?>
									<td>
										<?php
										if ($row['status'] == 0) {
											echo '<span class="badge badge-warning">Descartado</span>';
										} elseif ($row['status'] == 1) {
											echo '<span class="badge badge-success">Admitido</span>';
										}
										?>
									</td>
									<td><?php echo date('d M, Y', $row['created_on']); ?></td>
									<td>
										<?php
										if ($this->db->get_where('user', array('user_id' => $row['created_by']))->num_rows() > 0) {
											$staff_id = $this->security->xss_clean($this->db->get_where('user', array('user_id' => $row['created_by']))->row()->staff_id);
											$is_doctor = $this->security->xss_clean($this->db->get_where('user', array('user_id' => $row['created_by']))->row()->is_doctor);

											if ($is_doctor) {
												if ($this->db->get_where('doctor', array('doctor_id' => $staff_id))->num_rows() > 0)
													echo $this->security->xss_clean($this->db->get_where('doctor', array('doctor_id' => $staff_id))->row()->name);
												else 
													echo 'Doutor não foi encontrado.';
											} else {
												if ($this->db->get_where('staff', array('staff_id' => $staff_id))->num_rows() > 0)
													echo $this->security->xss_clean($this->db->get_where('staff', array('staff_id' => $staff_id))->row()->name);
												else
													echo 'Funcionario não foi encontrado.';
											}											
										} else {
											echo 'Criador não foi encontrado.';
										}
										?>
									</td>
									<td>
										<div class="btn-group">
											<button type="button" class="btn btn-white btn-xs">Acção</button>
											<button type="button" class="btn btn-white btn-xs dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
												<span class="sr-only">Toggle Dropdown</span>
											</button>
											<div class="dropdown-menu dropdown-menu-right">
												<a class="dropdown-item" onclick="showAjaxModal('<?php echo base_url(); ?>modal/popup/modal_view_occupancy_details/<?php echo $row['occupancy_id']; ?>');" href="javascript:;">ver Detalhes</a>
												<?php if ($this->session->userdata('user_type') == 'staff'): ?>
												<a class="dropdown-item" onclick="showAjaxModal('<?php echo base_url(); ?>modal/popup/modal_edit_occupancy_details/<?php echo $row['occupancy_id']; ?>');" href="javascript:;">Editar Detalhes</a>
												<div class="dropdown-divider"></div>
												<a class="dropdown-item" onclick="confirm_modal('<?php echo base_url(); ?>occupancies/delete/<?php echo $row['occupancy_id']; ?>');" href="javascript:;">Remover</a>
												<?php endif; ?>
											</div>
										</div>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
			<!-- end panel -->
		</div>
		<!-- end col-12 -->
	</div>
	<!-- end row -->
</div>
<!-- end #content -->