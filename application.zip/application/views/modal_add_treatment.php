<?php echo form_open('treatments/create', array('id' => 'create_treatment', 'class' => 'form-horizontal', 'method' => 'post', 'data-parsley-validate' => 'true')); ?>
<div class="form-group">
	<label class="col-md-12 col-form-label">Paciente *</label>
	<div class="col-md-12">
		<select style="width: 100%" class="form-control default-select2" name="patient_id" data-parsley-required="true">
			<option value="">Selecione o paciente</option>
			<?php
			$occupancies = $this->security->xss_clean($this->db->get_where('occupancy', array('status' => 1))->result_array());
			foreach ($occupancies as $occupancy) :
			?>
				<option value="<?php echo $occupancy['patient_id']; ?>"><?php echo $this->security->xss_clean($this->db->get_where('patient', array('patient_id' => $occupancy['patient_id']))->row()->name); ?></option>
			<?php endforeach; ?>
		</select>
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Doença *</label>
	<div class="col-md-12">
		<select style="width: 100%" class="form-control default-select2" name="disease_id" data-parsley-required="true">
			<option value="">Selecione a  doença</option>
			<?php
			$diseases = $this->security->xss_clean($this->db->get('disease')->result_array());
			foreach ($diseases as $disease) :
			?>
				<option value="<?php echo $disease['disease_id']; ?>"><?php echo $disease['name']; ?></option>
			<?php endforeach; ?>
		</select>
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">
		Selecione o  Medicamento(s) *
		<span class="btn btn-sm btn-yellow pull-right mt-7" id="add-more">
			<i class="fa fa-plus"></i>
			<span>Add mais</span>
		</span>
	</label>
	<div id="dynamic-field"></div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Sintomas *</label>
	<div class="col-md-12">
		<textarea name="symptoms" data-parsley-required="true" class="form-control" placeholder="" rows="5"></textarea>
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Notas extras</label>
	<div class="col-md-12">
		<textarea name="extra_note" class="form-control" placeholder="" rows="5"></textarea>
	</div>
</div>
<div class="form-group">
	<label class="col-md-12 col-form-label">Proximo  Checkup</label>
	<div class="col-md-12">
		<input name="next_checkup" id="masked-input-date" type="text" class="form-control" placeholder="mm/dd/yyyy" />
	</div>
</div>

<div class="form-group">
	<label class="col-md-12 col-form-label"></label>
	<div class="col-md-12">
		<button type="button" class="btn btn-warning" data-dismiss="modal" aria-label="Close">Cancelar</button>
		<button type="submit" class="btn btn-yellow pull-right">Submeter</button>
	</div>
</div>
<?php echo form_close(); ?>

<script>
	"use strict";

	$('#create_treatment').parsley();
	FormPlugins.init();
</script>

<script type="text/javascript">
	$(document).ready(function() {
		"use strict";

		var i = 0;
		$('#add-more').on('click', function() {
			i++;
			$('#dynamic-field').append(`
			<div  id="row` + i + `">				
				<div class="form-inline m-b-15">
					<div class="col-md-11">
						<select style="width: 100%" class="form-control default-select2" name="medicine_ids[]" data-parsley-required="true">
							<option value="">Select Medicine</option>
							<?php
							$medicines = $this->security->xss_clean($this->db->get('medicine')->result_array());
							foreach ($medicines as $medicine) :
							?>
								<option value="<?php echo $medicine['medicine_id']; ?>"><?php echo $medicine['name']; ?></option>
							<?php endforeach; ?>
						</select>					
					</div>
					<div class="col-md-1">
						<button type="button" name="remove" id="` + i + `" class="btn btn-sm btn-danger btn_remove pull-right">X</button>
					</div>
				</div>
				<div class="form-inline m-b-15">
					<div class="col-md-6">
						<input name="doses[]" type="text" data-parsley-required="true" class="form-control inline-input wd-100" placeholder="Doses" />
					</div>
					<div class="col-md-6">
						<input name="medication_times[]" type="text" data-parsley-required="true" class="form-control inline-input wd-100" placeholder="Times" />
					</div>
				</div>
			</div>
			`);

			FormPlugins.init();
		});

		$(document).on('click', '.btn_remove', function() {
			var button_id = $(this).attr("id");
			$('#row' + button_id).remove();
		});
	});
</script>