<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>#</th>
				<th>Nome</th>
				<th>Contexto</th>
			</tr>
		</thead>
		<tbody>
			<?php
			$count = 1;
			$patient_details = $this->db->get_where('patient', array('patient_id' => $param2))->result_array();
			foreach ($patient_details as $row) :
			?>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>E-mail</td>
					<td><?php if ($row['email']) echo $row['email'];
						else echo 'N/A'; ?></td>
				</tr>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>Profissão</td>
					<td>
						<?php 
							if ($row['profession_id']) {
								if ($this->db->get_where('profession', array('profession_id' => $row['profession_id']))->num_rows() > 0)
									echo $this->security->xss_clean($this->db->get_where('profession', array('profession_id' => $row['profession_id']))->row()->name);
								else
									echo 'Profissão não foi encontrada.';
							} else { echo 'N/A'; }
						?>
					</td>
				</tr>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>Endereço</td>
					<td><?php if ($row['address']) echo $row['address'];
						else echo 'N/A'; ?></td>
				</tr>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>Data de Aniversario</td>
					<td><?php if ($row['dob']) echo date('d M, Y', $row['dob']);
						else echo 'N/A'; ?></td>
				</tr>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>Pai Nome</td>
					<td><?php if ($row['father_name']) echo $row['father_name'];
						else echo 'N/A'; ?></td>
				</tr>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>Mãe Nome</td>
					<td><?php if ($row['mother_name']) echo $row['mother_name'];
						else echo 'N/A'; ?></td>
				</tr>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>Conatacto de Emergência</td>
					<td><?php if ($row['emergency_contact_relation']) echo $row['emergency_contact_relation'];
						else echo 'N/A'; ?></td>
				</tr>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>Criado em</td>
					<td><?php echo date('d M, Y', $row['created_on']); ?></td>
				</tr>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>Criado por</td>
					<td>
						<?php
						if ($this->db->get_where('user', array('user_id' => $row['created_by']))->num_rows() > 0) {
							$staff_id = $this->security->xss_clean($this->db->get_where('user', array('user_id' => $row['created_by']))->row()->staff_id);
							$is_doctor = $this->security->xss_clean($this->db->get_where('user', array('user_id' => $row['created_by']))->row()->is_doctor);

							if ($is_doctor) {
								if ($this->db->get_where('doctor', array('doctor_id' => $staff_id))->num_rows() > 0)
									echo $this->security->xss_clean($this->db->get_where('doctor', array('doctor_id' => $staff_id))->row()->name);
								else 
									echo 'Doutor não foi encontrado.';
							} else {
								if ($this->db->get_where('staff', array('staff_id' => $staff_id))->num_rows() > 0)
									echo $this->security->xss_clean($this->db->get_where('staff', array('staff_id' => $staff_id))->row()->name);
								else
									echo 'Funcionario não foi encontrado.';
							}											
						} else {
							echo 'Criador não foi encontrado.';
						}
						?>
					</td>
				</tr>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>Actualizado em</td>
					<td><?php echo date('d M, Y', $row['timestamp']); ?></td>
				</tr>
				<tr>
					<td><?php echo $count++; ?></td>
					<td>Actualizado por</td>
					<td>
						<?php
						if ($this->db->get_where('user', array('user_id' => $row['updated_by']))->num_rows() > 0) {
							$staff_id = $this->security->xss_clean($this->db->get_where('user', array('user_id' => $row['updated_by']))->row()->staff_id);
							$is_doctor = $this->security->xss_clean($this->db->get_where('user', array('user_id' => $row['updated_by']))->row()->is_doctor);

							if ($is_doctor) {
								if ($this->db->get_where('doctor', array('doctor_id' => $staff_id))->num_rows() > 0)
									echo $this->security->xss_clean($this->db->get_where('doctor', array('doctor_id' => $staff_id))->row()->name);
								else 
									echo 'Doutor não foi encontrado.';
							} else {
								if ($this->db->get_where('staff', array('staff_id' => $staff_id))->num_rows() > 0)
									echo $this->security->xss_clean($this->db->get_where('staff', array('staff_id' => $staff_id))->row()->name);
								else
									echo 'Funcionario não foi encontrado.';
							}											
						} else {
							echo 'Actualização não foi encontrado.';
						}
						?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<button type="button" class="btn btn-warning" data-dismiss="modal" aria-label="Close">Fechar</button>
</div>